package com.time_sheeet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeSheeetApplicationTests {

    @Test
    void contextLoads() {
    }

}
